sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("treinamento.alunosbycursos.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);
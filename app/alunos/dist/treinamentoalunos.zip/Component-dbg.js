sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("treinamento.alunos.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);
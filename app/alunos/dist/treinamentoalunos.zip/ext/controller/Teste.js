sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{teste:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Teste.js.map